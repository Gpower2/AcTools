#ifndef __Stdafx_H__
#define __Stdafx_H__

//C
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include <string.h>
#include <io.h>
#include <ctype.h>
#include <wtypes.h>

//windows
#define WIN32_LEAN_AND_MEAN
#include <objbase.h>
#include <vfw.h>
#include <windows.h>
#include <mmsystem.h>
#include <msacm.h>

//STL
#include <vector>
#include <algorithm>

#endif // __Stdafx_H__
