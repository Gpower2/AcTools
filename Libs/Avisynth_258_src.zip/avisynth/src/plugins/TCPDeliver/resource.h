//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClientGUI.rc
//
#define IDD_SERVERGUI                   101
#define IDI_ICON                        103
#define IDD_CLIENTGUI                   106
#define IDC_IP                          1000
#define IDC_EDIT2                       1001
#define IDC_PORT_TEXT                   1002
#define IDC_RECONNECT_BUTTON            1003
#define IDC_STATUS                      1004
#define IDC_FRAME_INFORMATION           1005
#define IDC_TIMESTATS                   1007
#define IDC_SERVERSTATUS                1008
#define IDC_STATUS_GROUP                1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
