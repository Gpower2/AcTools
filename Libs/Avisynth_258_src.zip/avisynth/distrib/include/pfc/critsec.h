#ifndef _PFC_CRITSEC_H_
#define _PFC_CRITSEC_H_

#error MOVED TO UTF8API.H

#endif