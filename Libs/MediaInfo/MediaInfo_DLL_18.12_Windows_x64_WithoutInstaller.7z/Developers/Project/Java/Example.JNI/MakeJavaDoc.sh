mkdir javadoc
javadoc -d ./javadoc -classpath JNI.jar ../../../Source/MediaInfoDLL/MediaInfoDLL.JNI.java
